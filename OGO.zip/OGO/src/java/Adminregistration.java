
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Adminregistration extends HttpServlet 
{

        
    public void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
            /* TODO output your page here. You may use following sample code. */
            
		String sNm = request.getParameter("Nm");
		String sPw = request.getParameter("Pw");
		String sUn = request.getParameter("Un");
		String sRl = request.getParameter("Rl");
		String Database = getServletContext().getInitParameter("DB_Name");
                String Password = getServletContext().getInitParameter("DB_Password");
                
                if(sNm.equals("") | sPw.equals("") | sUn.equals("") | sRl.equals(""))
                {
                    out.println("<html><head></head><body onload=\"alert('Please fill the registration form properly.')\"></body></html>");
                    //out.println("Please fill the registration form properly.<br>");
                    RequestDispatcher rd = request.getRequestDispatcher("adminregister.jsp");
                    rd.include(request,response);
                    request = null;
                    response = null;
                }
		
		try
                {
                //out.println("start<br>");
                Class.forName("oracle.jdbc.driver.OracleDriver");
                //out.println("load driver<br>");
                Connection cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",Database,Password);
                //out.println("connt. made<br>");
                Statement st=cn.createStatement();
                //out.println("statement created<br>");
                
                
                String sCheck = "select * from ADMIN where USERNAME='"+sUn+"'";
                ResultSet rs1=st.executeQuery(sCheck);
        while(rs1.next())
        {
            //String usersNm = rs1.getString(1);
            //String usersLn = rs1.getString(2);
            //Long usersRl = rs1.getLong(3);
            String usersUn = rs1.getString(4);
            //String usersPw = rs1.getString(5);
            //String usersId = rs1.getString(6);
            out.println(usersUn+"<br>");

            if(usersUn.equals(sUn))
                    {
                        /*out.println("<script type=\"text/javascript\">");
                        out.println("alert('This E-Mail ID is already registered...Please use another E-Mail!!!');");
                        out.println("location='register.jsp';");
                        out.println("</script>");*/
                        
                    out.println("<html><head></head><body onload=\"alert('This Username is already registered...Please use another Username.')\"></body></html>");
                    //out.println("This E-Mail ID is already registered...Please use another E-Mail!!!<br>");
                    //response.sendRedirect("Welcome");
                    
                    RequestDispatcher rd = request.getRequestDispatcher("adminregister.jsp");
                    rd.include(request,response);
                    request = null;
                    response = null;
                    //out.println("<a href=\"RegistrationGUI.jsp\">Go Back</a>");
                    }
            //out.println("<br>"+usersNm+"<br>"+usersLn+"<br>"+usersRl+"<br>"+usersUn+"<br>"+usersPw);
            
            //out.println("<br>"+rs.getString(1)+"<br>"+rs.getString(2)+"<br>"+rs.getLong(3)+"<br>"+rs.getString(4)+"<br>"+rs.getString(5));
        }
                out.println("ready to update table<br>");
                int x=st.executeUpdate("insert into ADMIN values('','"+sNm+"','"+sPw+"','"+sUn+"','"+sRl+"')");
                out.println("update table<br>");
                String sLogin = "SELECT * FROM ADMIN WHERE USERNAME = '"+sUn+"' AND PASSWORD = '"+sPw+"'";
                ResultSet rs=st.executeQuery(sLogin);
                out.println("Table is Updated<br>");
                
        while(rs.next())
        {
            String usersNm = rs.getString(2);
            String usersPw = rs.getString(3);
            String usersUn = rs.getString(4);
            String usersRl = rs.getString(5);
            

            if(usersUn != null)
                    {
                    HttpSession session = request.getSession();
                    session.setAttribute("adminusername",usersNm);
                    session.setAttribute("E-Mail",usersUn);
                    response.sendRedirect("welcome.jsp");
                    //RequestDispatcher rd = request.getRequestDispatcher("Welcome");
                    //rd.forward(request,response);
                    }
            out.println("<br>"+usersNm+"<br>"+usersPw+"<br>"+usersUn+"<br>"+usersRl);
            
            //out.println("<br>"+rs.getString(1)+"<br>"+rs.getString(2)+"<br>"+rs.getLong(3)+"<br>"+rs.getString(4)+"<br>"+rs.getString(5));
        }

                
                //ResultSet rs=st.executeQuery("select * from student");
                out.println("ready");
                
                }
                catch(Exception e)
                {out.println();}
                out.println("</body></html>");    
    }
    
}
