
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Registration extends HttpServlet 
{

        
    public void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
            /* TODO output your page here. You may use following sample code. */
            
		String sFn = request.getParameter("Fn");
        String sLn = request.getParameter("Ln");
		String sPw = request.getParameter("Pw");
		String sEm = request.getParameter("Em");
		String sMb = request.getParameter("Mb");
		String sAd = request.getParameter("Ad");
                String Database = getServletContext().getInitParameter("DB_Name");
                String Password = getServletContext().getInitParameter("DB_Password");
                        
                
                if(sFn.equals("") | sPw.equals("") | sEm.equals("") | sMb.equals("") | sAd.equals(""))
                {
                    out.println("<html><head></head><body onload=\"alert('Please fill the registration form properly.')\"></body></html>");
                    //out.println("Please fill the registration form properly.<br>");
                    RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
                    rd.include(request,response);
                    request = null;
                    response = null;
                }
		
		try
                {
                //out.println("start<br>");
                Class.forName("oracle.jdbc.driver.OracleDriver");
                //out.println("load driver<br>");
                Connection cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",Database,Password);
                //out.println("connt. made<br>");
                Statement st=cn.createStatement();
                //out.println("statement created<br>");
                
                
                String sCheck = "select * from USERS_DATAS where E_MAIL='"+sEm+"'";
                ResultSet rs1=st.executeQuery(sCheck);
        while(rs1.next())
        {
            //String usersFn = rs1.getString(1);
            //String usersLn = rs1.getString(2);
            //Long usersMb = rs1.getLong(3);
            String usersEm = rs1.getString(4);
            //String usersPw = rs1.getString(5);
            //String usersId = rs1.getString(6);
            out.println(usersEm+"<br>");

            if(usersEm.equals(sEm))
                    {
                        /*out.println("<script type=\"text/javascript\">");
                        out.println("alert('This E-Mail ID is already registered...Please use another E-Mail!!!');");
                        out.println("location='register.jsp';");
                        out.println("</script>");*/
                        
                    out.println("<html><head></head><body onload=\"alert('This E-Mail ID is already registered...Please use another E-Mail!!!')\"></body></html>");
                    //out.println("This E-Mail ID is already registered...Please use another E-Mail!!!<br>");
                    //response.sendRedirect("Welcome");
                    
                    RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
                    rd.include(request,response);
                    request = null;
                    response = null;
                    //out.println("<a href=\"RegistrationGUI.jsp\">Go Back</a>");
                    }
            //out.println("<br>"+usersFn+"<br>"+usersLn+"<br>"+usersMb+"<br>"+usersEm+"<br>"+usersPw);
            
            //out.println("<br>"+rs.getString(1)+"<br>"+rs.getString(2)+"<br>"+rs.getLong(3)+"<br>"+rs.getString(4)+"<br>"+rs.getString(5));
        }

                int x=st.executeUpdate("insert into USERS_DATAS values('"+sFn+"','"+sLn+"',"+sMb+",'"+sEm+"','"+sPw+"','','"+sAd+"')");
                out.println("update table<br>");
                String sLogin = "SELECT * FROM USERS_DATAS WHERE E_MAIL = '"+sEm+"' AND PASSWORD = '"+sPw+"'";
                ResultSet rs=st.executeQuery(sLogin);
                out.println("Table is Updated<br>");
                
        while(rs.next())
        {
            String usersFn = rs.getString(1);
            String usersLn = rs.getString(2);
            Long usersMb = rs.getLong(3);
            String usersEm = rs.getString(4);
            String usersPw = rs.getString(5);
            String usersId = rs.getString(6);
            String usersAd = rs.getString(7);

            if(usersEm != null)
                    {
                    HttpSession session = request.getSession();
                    session.setAttribute("username",usersFn);
                    session.setAttribute("E-Mail",usersEm);
                    response.sendRedirect("welcome.jsp");
                    //RequestDispatcher rd = request.getRequestDispatcher("Welcome");
                    //rd.forward(request,response);
                    }
            out.println("<br>"+usersFn+"<br>"+usersLn+"<br>"+usersMb+"<br>"+usersEm+"<br>"+usersPw+"<br>"+usersAd);
            
            //out.println("<br>"+rs.getString(1)+"<br>"+rs.getString(2)+"<br>"+rs.getLong(3)+"<br>"+rs.getString(4)+"<br>"+rs.getString(5));
        }

                
                //ResultSet rs=st.executeQuery("select * from student");
                out.println("ready");
                
                }
                catch(Exception e)
                {out.println();}
                out.println("</body></html>");    
    }
    
}
