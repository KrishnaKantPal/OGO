

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class Welcome extends HttpServlet 
{

    public void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String Database = getServletContext().getInitParameter("DB_Name");
        String Password = getServletContext().getInitParameter("DB_Password");
        HttpSession session1 = request.getSession();
        String userEMail = (String)session1.getAttribute("E-Mail");
        out.println("<html><body>");
            
        try
        {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        //out.println("Driver class loaded");
        Connection cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",Database,Password);
        //out.println("Connection created");
        Statement st=cn.createStatement();
        //out.println("Statement created");
        //out.println("Executed the query");
        ResultSet rs=st.executeQuery("select * from USERS_DATAS where E_MAIL='"+userEMail+"'");
        //out.println("Executed");
        while(rs.next())
        {
            String usersFn = rs.getString(1);
            String usersLn = rs.getString(2);
            Long usersMb = rs.getLong(3);
            String usersEm = rs.getString(4);
            String usersPw = rs.getString(5);
            String usersId = rs.getString(6);
            String usersAd = rs.getString(7);
            
            
            out.println("<div class=\"span9\">");
            out.println("<table class=\"table table-striped\"><thead><tr><th><h1>Hi </h1></th><th><h1>"+usersFn+"</h1></th></tr></thead>"
                    + "<tbody><tr><td><h3>Name</h3></td><td><h4>"+usersFn+" "+usersLn+".</h4></td></tr>"
                    + "<tr><td><h3>Mobile</h3></td><td><h4>"+usersMb+".</h4></td></tr>"
                    + "<tr><td><h3>Email</h3></td><td><h4>"+usersEm+".</h4></td></tr>"
                    + "<tr><td><h3>Address</h3></td><td><h4>"+usersAd+".</h4></td></tr></tbody></table>");
             
        }
        }
        catch(Exception e)
        {out.println(e);}
        
        out.println("</body></html>");
        
        //session.invalidate();    
            
        
    }
        
}

