
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class Products extends HttpServlet {

    public void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
//        String sEm = request.getParameter("e_mail");
//        String sPw = request.getParameter("password");
        String Database = getServletContext().getInitParameter("DB_Name");
        String Password = getServletContext().getInitParameter("DB_Password");

//        if(sPw.equals("") | sEm.equals(""))
//                {
//                    out.println("<html><head></head><body onload=\"alert('Please fill the registration form properly.')\"></body></html>");
//                    //out.println("Please fill the registration form properly.<br>");
//                    RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
//                    rd.include(request,response);
//                    request = null;
//                    response = null;
//                }
        out.println("<html><body>");
        String url = "themes/images/ladies/5.jpg";
        String Pro_Name = "Shri Shri Ayurveda";
        String Category = "Flours and Grains";
        String Price = "256";
//        out.println(message);
        request.setAttribute("url", url);
        request.setAttribute("Pro_Name", Pro_Name);
        request.setAttribute("Category", Category);
        request.setAttribute("Price", Price);
//                RequestDispatcher rd = request.getRequestDispatcher("products.jsp");
//                rd.include(request, response);
//                request = null;
//                response = null;
                
        Student s1=new Student(1,"AAA",13);  
        Student s2=new Student(2,"BBB",14);  
        Student s3=new Student(3,"CCC",15);
        
        ArrayList<Student> al=new ArrayList<>();
        al.add(s1);
        al.add(s2);  
        al.add(s3);
        
        Iterator itr=al.iterator();
        while(itr.hasNext()){  
            Student st=(Student)itr.next();  
            out.println(st.rollno+" "+st.name+" "+st.age);  
        }

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection cn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", Database, Password);
            Statement st = cn.createStatement();
            String sLogin = "select * from PRODUCT where PRO_ID > '1'";
            ResultSet rs = st.executeQuery(sLogin);

            while (rs.next()) {
                Long PRO_ID = rs.getLong(1);
                String PRO_NAME = rs.getString(2);
                String CATEGORY = rs.getString(3);
                Long PRICE = rs.getLong(4);
                Long DISCOUNT = rs.getLong(5);
                String BRAND = rs.getString(6);
                String PRO_IMG = rs.getString(7);
                String DESCRIPTION = rs.getString(8);

            out.println("<br>"+PRO_ID+"<br>"+PRO_NAME+"<br>"+CATEGORY+"<br>"+PRICE+"<br>"+DISCOUNT+"<br>"+BRAND+"<br>"+PRO_IMG+"<br>"+DESCRIPTION);
//                out.println("<li class=\"span3\">\n" +
//"								<div class=\"product-box\">\n" +
//"									<span class=\"sale_tag\"></span>												\n" +
//"									<a href=\"product_detail.jsp\"><img alt=\"Product\" src=\"+PRO_IMG+\"></a><br/>\n" +
//"									<a href=\"product_detail.jsp\" class=\"title\">"+PRO_NAME+"</a><br/>\n" +
//"									<a href=\"#\" class=\"category\">"+CATEGORY+"</a>\n" +
//"									<p class=\"price\">$"+PRICE+"</p>\n" +
//"								</div>\n" +
//"							</li>");
                
//                out.println("<li class=\"span3\">");
//                out.println("<div class=\"product-box\">");
//                out.println("<a href=\"product_detail.jsp\"><img alt=\"\" src=\"themes/images/ladies/6.jpg\"></a><br/>");
//                out.println("<a href=\"product_detail.jsp\" class=\"title\">Praesent tempor sem</a><br/>");
//                out.println("<a href=\"#\" class=\"category\">Erat gravida</a>");
//                out.println("<p class=\"price\">$28</p>");
//                out.println("</div>");
//                out.println("</li>");
                
                
//                out.println("<br>" + rs.getString(1) + "<br>" + rs.getString(2) + "<br>" + rs.getLong(3) + "<br>" + rs.getString(4) + "<br>" + rs.getString(5) + "<br>" + rs.getLong(6));
            }

            if (!rs.next()) {
                out.println("<html><head></head><body onload=\"alert('No record found.')\"></body></html>");
                //out.println("You entered wrong E-Mail or password");
//                RequestDispatcher rd = request.getRequestDispatcher("products.jsp");
//                rd.include(request, response);
                //request = null;
                //response = null;
            }

        } catch (SQLException e1) {
            out.println(e1 + " Please Enter the correct E-Mail & Password...........");

        } catch (Exception e2) {
            out.println(e2);

        }

        out.println("</body></html>");

    }

}

class Student{  
    int rollno;  
    String name;  
    int age;  
    Student(int rollno,String name,int age){  
        this.rollno=rollno;  
        this.name=name;  
        this.age=age;  
    }  
}
