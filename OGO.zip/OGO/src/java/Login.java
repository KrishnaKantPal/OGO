import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class Login extends HttpServlet
{
    public void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String sEm = request.getParameter("e_mail");
        String sPw = request.getParameter("password");
        String Database = getServletContext().getInitParameter("DB_Name");
        String Password = getServletContext().getInitParameter("DB_Password");
        
        if(sPw.equals("") | sEm.equals(""))
                {
                    out.println("<html><head></head><body onload=\"alert('Please fill the registration form properly.')\"></body></html>");
                    //out.println("Please fill the registration form properly.<br>");
                    RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
                    rd.include(request,response);
                    request = null;
                    response = null;
                }
        
        out.println("<html><body>");
        
	try
        {
        //out.println("You Entered...<br>");
        //out.println(sEm+"<br>");
        //out.println(sPw+"<br>");
        Class.forName("oracle.jdbc.driver.OracleDriver");
        //out.println("Driver class loaded<br>");
        Connection cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",Database,Password);
        //out.println("Connection created<br>");
        Statement st=cn.createStatement();
        //out.println("Statement created<br>");
        //out.println("Executed the query<br>");
        //out.println("You entered wrong E-Mail or password");
        //RequestDispatcher rd = request.getRequestDispatcher("LoginGUI.jsp");
        //rd.include(request,response);
        String sLogin = "select * from USERS_DATAS where E_MAIL='"+sEm+"' AND PASSWORD='"+sPw+"'";
        ResultSet rs=st.executeQuery(sLogin);
        //out.println(rs.next());
        //out.println("Executed<br>");
        
        while(rs.next())
        {
            String usersFn = rs.getString(1);
            String usersLn = rs.getString(2);
            Long usersMb = rs.getLong(3);
            String usersEm = rs.getString(4);
            String usersPw = rs.getString(5);
            String usersId = rs.getString(6);
            
            out.println("<br>"+usersFn+"<br>"+usersLn+"<br>"+usersMb+"<br>"+usersEm+"<br>"+usersPw);
            if(sEm.equals(usersEm))
                {
                HttpSession session = request.getSession();
                session.setAttribute("username",usersFn);
                session.setAttribute("E-Mail",usersEm);
                response.sendRedirect("welcome.jsp");
                //RequestDispatcher rd = request.getRequestDispatcher("Welcome");
                //rd.forward(request,response);
                }
        out.println("<br>"+rs.getString(1)+"<br>"+rs.getString(2)+"<br>"+rs.getLong(3)+"<br>"+rs.getString(4)+"<br>"+rs.getString(5)+"<br>"+rs.getLong(6));
        }
        
        if(!rs.next())
        {
            out.println("<html><head></head><body onload=\"alert('You entered wrong E-Mail or password')\"></body></html>");
            //out.println("You entered wrong E-Mail or password");
            RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
            rd.include(request,response);
            //request = null;
            //response = null;
        }
        
        
        
        
         
        }
        catch(SQLException e1)
        {
            out.println(e1+" Please Enter the correct E-Mail & Password...........");
            
        }
        
        catch(Exception e2)
        {
            out.println(e2);
            
        }
        
        
        out.println("</body></html>");    
        
    }

  
}
